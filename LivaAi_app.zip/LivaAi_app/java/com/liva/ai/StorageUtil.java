package com.liva.ai;

import android.content.Context;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

public class StorageUtil {
    private static final String FILE_NAME = "chat_history.json";
    private static Gson gson = new Gson();
    
    public static void saveMessages(Context context, List<MessageModel> messages) {
        try {
            String json = gson.toJson(messages);
            FileOutputStream fos = context.openFileOutput(FILE_NAME, Context.MODE_PRIVATE);
            fos.write(json.getBytes());
            fos.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public static List<MessageModel> loadMessages(Context context) {
        try {
            FileInputStream fis = context.openFileInput(FILE_NAME);
            BufferedReader reader = new BufferedReader(new InputStreamReader(fis));
            StringBuilder stringBuilder = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                stringBuilder.append(line);
            }
            reader.close();
            fis.close();
            
            Type listType = new TypeToken<ArrayList<MessageModel>>(){}.getType();
            return gson.fromJson(stringBuilder.toString(), listType);
        } catch (Exception e) {
            return new ArrayList<>();
        }
    }
    
    public static void clearMessages(Context context) {
        try {
            context.deleteFile(FILE_NAME);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}