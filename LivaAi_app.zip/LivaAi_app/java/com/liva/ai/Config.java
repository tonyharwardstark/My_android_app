package com.liva.ai;

public class Config {
    // REPLACE WITH YOUR ACTUAL API KEY
    public static final String API_KEY = "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";
}