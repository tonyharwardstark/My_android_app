package com.liva.ai;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Locale;

public class ChatAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    
    private static final int TYPE_USER = 1;
    private static final int TYPE_ASSISTANT = 2;
    private static final int TYPE_TYPING = 3;
    
    private List<MessageModel> messageList;
    private OnMessageActionListener actionListener;
    private SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm", Locale.getDefault());
    
    public ChatAdapter(List<MessageModel> messageList, OnMessageActionListener actionListener) {
        this.messageList = messageList;
        this.actionListener = actionListener;
    }
    
    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        
        if (viewType == TYPE_USER) {
            View view = inflater.inflate(R.layout.item_message_user, parent, false);
            return new UserMessageViewHolder(view);
        } else if (viewType == TYPE_ASSISTANT) {
            View view = inflater.inflate(R.layout.item_message_assistant, parent, false);
            return new AssistantMessageViewHolder(view);
        } else {
            View view = inflater.inflate(R.layout.view_typing_indicator, parent, false);
            return new TypingIndicatorViewHolder(view);
        }
    }
    
    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        if (holder.getItemViewType() == TYPE_USER) {
            ((UserMessageViewHolder) holder).bind(messageList.get(position));
        } else if (holder.getItemViewType() == TYPE_ASSISTANT) {
            ((AssistantMessageViewHolder) holder).bind(messageList.get(position));
        }
    }
    
    @Override
    public int getItemCount() {
        return messageList.size();
    }
    
    @Override
    public int getItemViewType(int position) {
        MessageModel message = messageList.get(position);
        if (message.getRole().equals("user")) {
            return TYPE_USER;
        } else if (message.getRole().equals("assistant")) {
            return TYPE_ASSISTANT;
        } else {
            return TYPE_TYPING;
        }
    }
    
    class UserMessageViewHolder extends RecyclerView.ViewHolder {
        TextView messageText, timeText;
        
        UserMessageViewHolder(View itemView) {
            super(itemView);
            messageText = itemView.findViewById(R.id.messageText);
            timeText = itemView.findViewById(R.id.timeText);
        }
        
        void bind(MessageModel message) {
            messageText.setText(message.getMessage());
            timeText.setText(timeFormat.format(message.getTimestamp()));
        }
    }
    
    class AssistantMessageViewHolder extends RecyclerView.ViewHolder {
        TextView messageText, timeText;
        ImageView avatar, speakButton;
        
        AssistantMessageViewHolder(View itemView) {
            super(itemView);
            messageText = itemView.findViewById(R.id.messageText);
            timeText = itemView.findViewById(R.id.timeText);
            avatar = itemView.findViewById(R.id.avatar);
            speakButton = itemView.findViewById(R.id.speakButton);
        }
        
        void bind(MessageModel message) {
            messageText.setText(message.getMessage());
            timeText.setText(timeFormat.format(message.getTimestamp()));
            
            speakButton.setOnClickListener(v -> {
                if (actionListener != null) {
                    actionListener.onSpeakMessage(message.getMessage());
                }
            });
        }
    }
    
    class TypingIndicatorViewHolder extends RecyclerView.ViewHolder {
        TypingIndicatorViewHolder(View itemView) {
            super(itemView);
        }
    }
    
    public interface OnMessageActionListener {
        void onSpeakMessage(String message);
    }
}