package com.liva.ai;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Response;

public class MainActivity extends AppCompatActivity implements TextToSpeech.OnInitListener {
    
    private RecyclerView recyclerView;
    private ChatAdapter adapter;
    private List<MessageModel> messageList;
    private EditText inputEditText;
    private ImageButton sendButton, micButton;
    private View typingIndicator;
    
    private SpeechRecognizer speechRecognizer;
    private TextToSpeech textToSpeech;
    private boolean isListening = false;
    private static final int RECORD_AUDIO_PERMISSION_CODE = 101;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        initializeViews();
        setupRecyclerView();
        initializeSpeechComponents();
        loadChatHistory();
        
        findViewById(R.id.clearChat).setOnClickListener(v -> clearChat());
    }
    
    private void initializeViews() {
        recyclerView = findViewById(R.id.recyclerView);
        inputEditText = findViewById(R.id.inputEditText);
        sendButton = findViewById(R.id.sendButton);
        micButton = findViewById(R.id.micButton);
        typingIndicator = findViewById(R.id.typingIndicator);
        
        sendButton.setOnClickListener(v -> sendMessage());
        micButton.setOnClickListener(v -> toggleSpeechRecognition());
    }
    
    private void setupRecyclerView() {
        messageList = new ArrayList<>();
        adapter = new ChatAdapter(messageList, this::speakMessage);
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
    }
    
    private void initializeSpeechComponents() {
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this);
        speechRecognizer.setRecognitionListener(new RecognitionListener() {
            @Override
            public void onReadyForSpeech(Bundle params) {}
            
            @Override
            public void onBeginningOfSpeech() {}
            
            @Override
            public void onRmsChanged(float rmsdB) {}
            
            @Override
            public void onBufferReceived(byte[] buffer) {}
            
            @Override
            public void onEndOfSpeech() {}
            
            @Override
            public void onError(int error) {
                isListening = false;
                updateMicButtonState();
            }
            
            @Override
            public void onResults(Bundle results) {
                ArrayList<String> matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if (matches != null && !matches.isEmpty()) {
                    inputEditText.setText(matches.get(0));
                }
                isListening = false;
                updateMicButtonState();
            }
            
            @Override
            public void onPartialResults(Bundle partialResults) {}
            
            @Override
            public void onEvent(int eventType, Bundle params) {}
        });
        
        textToSpeech = new TextToSpeech(this, this);
    }
    
    private void sendMessage() {
        String message = inputEditText.getText().toString().trim();
        if (TextUtils.isEmpty(message)) return;
        
        addMessageToChat(message, "user", System.currentTimeMillis());
        inputEditText.setText("");
        showTypingIndicator();
        
        NetworkClient.getInstance().sendMessageToAPI(message, new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                runOnUiThread(() -> {
                    hideTypingIndicator();
                    Toast.makeText(MainActivity.this, "Network error", Toast.LENGTH_SHORT).show();
                });
            }
            
            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (response.isSuccessful()) {
                    try {
                        String responseBody = response.body().string();
                        JSONObject jsonResponse = new JSONObject(responseBody);
                        JSONArray choices = jsonResponse.getJSONArray("choices");
                        if (choices.length() > 0) {
                            JSONObject choice = choices.getJSONObject(0);
                            JSONObject messageObj = choice.getJSONObject("message");
                            String assistantMessage = messageObj.getString("content");
                            
                            runOnUiThread(() -> {
                                hideTypingIndicator();
                                addMessageToChat(assistantMessage, "assistant", System.currentTimeMillis());
                            });
                        }
                    } catch (JSONException e) {
                        runOnUiThread(() -> {
                            hideTypingIndicator();
                            Toast.makeText(MainActivity.this, "Response parsing error", Toast.LENGTH_SHORT).show();
                        });
                    }
                } else {
                    runOnUiThread(() -> {
                        hideTypingIndicator();
                        Toast.makeText(MainActivity.this, "API error", Toast.LENGTH_SHORT).show();
                    });
                }
            }
        });
    }
    
    private void addMessageToChat(String message, String role, long timestamp) {
        MessageModel newMessage = new MessageModel(message, role, timestamp);
        messageList.add(newMessage);
        adapter.notifyItemInserted(messageList.size() - 1);
        recyclerView.scrollToPosition(messageList.size() - 1);
        StorageUtil.saveMessages(this, messageList);
    }
    
    private void showTypingIndicator() {
        typingIndicator.setVisibility(View.VISIBLE);
        adapter.notifyItemInserted(messageList.size());
        recyclerView.scrollToPosition(messageList.size() - 1);
    }
    
    private void hideTypingIndicator() {
        typingIndicator.setVisibility(View.GONE);
    }
    
    private void toggleSpeechRecognition() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) 
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, 
                    new String[]{Manifest.permission.RECORD_AUDIO}, 
                    RECORD_AUDIO_PERMISSION_CODE);
            return;
        }
        
        if (!isListening) {
            speechRecognizer.startListening(RecognizerIntent.getVoiceDetailsIntent(this));
            isListening = true;
        } else {
            speechRecognizer.stopListening();
            isListening = false;
        }
        updateMicButtonState();
    }
    
    private void updateMicButtonState() {
        micButton.setColorFilter(isListening ? 
                ContextCompat.getColor(this, R.color.colorPrimary) : 
                ContextCompat.getColor(this, R.color.textSecondary));
    }
    
    private void speakMessage(String message) {
        if (textToSpeech != null) {
            textToSpeech.speak(message, TextToSpeech.QUEUE_FLUSH, null, null);
        }
    }
    
    private void loadChatHistory() {
        List<MessageModel> savedMessages = StorageUtil.loadMessages(this);
        if (savedMessages != null) {
            messageList.clear();
            messageList.addAll(savedMessages);
            adapter.notifyDataSetChanged();
            if (!messageList.isEmpty()) {
                recyclerView.scrollToPosition(messageList.size() - 1);
            }
        }
    }
    
    private void clearChat() {
        messageList.clear();
        adapter.notifyDataSetChanged();
        StorageUtil.clearMessages(this);
    }
    
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == RECORD_AUDIO_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                toggleSpeechRecognition();
            } else {
                Toast.makeText(this, "Microphone permission required", Toast.LENGTH_SHORT).show();
            }
        }
    }
    
    @Override
    public void onInit(int status) {
        if (status == TextToSpeech.SUCCESS) {
            textToSpeech.setLanguage(Locale.getDefault());
        }
    }
    
    @Override
    protected void onDestroy() {
        if (speechRecognizer != null) {
            speechRecognizer.destroy();
        }
        if (textToSpeech != null) {
            textToSpeech.stop();
            textToSpeech.shutdown();
        }
        super.onDestroy();
    }
}