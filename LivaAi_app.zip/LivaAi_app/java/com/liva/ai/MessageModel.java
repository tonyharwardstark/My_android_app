package com.liva.ai;

public class MessageModel {
    private String message;
    private String role;
    private long timestamp;
    
    public MessageModel() {}
    
    public MessageModel(String message, String role, long timestamp) {
        this.message = message;
        this.role = role;
        this.timestamp = timestamp;
    }
    
    public String getMessage() {
        return message;
    }
    
    public void setMessage(String message) {
        this.message = message;
    }
    
    public String getRole() {
        return role;
    }
    
    public void setRole(String role) {
        this.role = role;
    }
    
    public long getTimestamp() {
        return timestamp;
    }
    
    public void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
    }
}