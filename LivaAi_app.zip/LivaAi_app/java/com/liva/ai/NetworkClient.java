package com.liva.ai;

import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class NetworkClient {
    private static NetworkClient instance;
    private OkHttpClient client;
    private static final MediaType JSON = MediaType.get("application/json; charset=utf-8");
    
    private NetworkClient() {
        client = new OkHttpClient();
    }
    
    public static NetworkClient getInstance() {
        if (instance == null) {
            instance = new NetworkClient();
        }
        return instance;
    }
    
    public void sendMessageToAPI(String userMessage, Callback callback) {
        try {
            JSONObject requestBody = new JSONObject();
            requestBody.put("model", "gpt-3.5-turbo");
            
            JSONArray messages = new JSONArray();
            JSONObject message = new JSONObject();
            message.put("role", "user");
            message.put("content", userMessage);
            messages.put(message);
            
            requestBody.put("messages", messages);
            
            Request request = new Request.Builder()
                    .url("https://openrouter.ai/api/v1/chat/completions")
                    .post(RequestBody.create(requestBody.toString(), JSON))
                    .addHeader("Authorization", "Bearer " + Config.API_KEY)
                    .addHeader("Content-Type", "application/json")
                    .build();
            
            client.newCall(request).enqueue(callback);
            
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
}